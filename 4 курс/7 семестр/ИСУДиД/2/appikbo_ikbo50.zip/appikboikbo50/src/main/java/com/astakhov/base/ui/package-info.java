@NullMarked
package com.astakhov.base.ui;

import org.jspecify.annotations.NullMarked;